// ignore_for_file: camel_case_types

class Item {
  final String text;
  final String imageUrl;
  

  Item({required this.text, required this.imageUrl});
}

class statusType {
  final String text;

  statusType({required this.text});
}
