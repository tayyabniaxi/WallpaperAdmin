// // ignore_for_file: use_build_context_synchronously

// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:new_wall_paper_app/audio-to-text/model/store-pdf-sqlite-db-model.dart';
// import 'package:new_wall_paper_app/audio-to-text/page/write-past-text.dart';
// import 'package:new_wall_paper_app/widget/sqlite-helper.dart';

// import 'package:flutter/material.dart';
// // import 'package:new_wall_paper_app/audio-to-text/model/store-pdf-sqlite-db-model.dart';
// // import 'package:new_wall_paper_app/audio-to-text/db_helper.dart';

// class OpenedPdfsPage extends StatefulWidget {
//   const OpenedPdfsPage({Key? key}) : super(key: key);

//   @override
//   _OpenedPdfsPageState createState() => _OpenedPdfsPageState();
// }

// class _OpenedPdfsPageState extends State<OpenedPdfsPage> {
//   late Future<List<Document>> _savedDocuments;

//   @override
//   void initState() {
//     super.initState();
//     _savedDocuments = DatabaseHelper().getDocuments();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       bottomNavigationBar: const Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [],
//       ),
//       appBar: AppBar(
//         title: const Text("Saved PDF Contents"),
//       ),
//       body: FutureBuilder<List<Document>>(
//         future: _savedDocuments,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           } else if (snapshot.hasError) {
//             return Center(child: Text("Error: ${snapshot.error}"));
//           } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
//             return const Center(child: Text("No saved content found"));
//           } else {
//             final documents = snapshot.data!;
//             return ListView.builder(
//               itemCount: documents.length,
//               itemBuilder: (context, index) {
//                 final document = documents[index];
//                 return ListTile(
//                   leading: CircleAvatar(
//                     radius: MediaQuery.of(context).size.height * 0.03,
//                     child: Text(
//                       document.contentType == "PDF"
//                           ? "PDF"
//                           : document.contentType == "Image"
//                               ? "Image"
//                               : document.contentType == "Link"
//                                   ? "Link"
//                                   : document.contentType == "DOCX"
//                                       ? "DOCX"
//                                       : document.contentType == "Email"
//                                           ? "Email"
//                                           : "",
//                       style: const TextStyle(fontSize: 11),
//                     ),
//                   ),
//                   trailing: IconButton(
//                     onPressed: () async {
//                       final confirm = await showDialog<bool>(
//                         context: context,
//                         builder: (context) => AlertDialog(
//                           title: const Text("Delete Document"),
//                           content: Text(
//                               "Are you sure you want to delete '${document.name}'?"),
//                           actions: [
//                             TextButton(
//                               onPressed: () => Navigator.of(context).pop(false),
//                               child: const Text("Cancel"),
//                             ),
//                             TextButton(
//                               onPressed: () => Navigator.of(context).pop(true),
//                               child: const Text("Delete"),
//                             ),
//                           ],
//                         ),
//                       );

//                       if (confirm == true) {
//                         final dbHelper = DatabaseHelper();
//                         await dbHelper.deleteDocument(document.id!);

//                         setState(() {
//                           documents
//                               .removeAt(index); 
//                         });

//                         ScaffoldMessenger.of(context).showSnackBar(
//                           SnackBar(
//                               content:
//                                   Text("Document '${document.name}' deleted")),
//                         );
//                       }
//                     },
//                     icon: const Icon(
//                       Icons.delete,
//                       color: Colors.red,
//                     ),
//                   ),
//                   title: Text("${document.name}"),
//                   subtitle: Text(document.description.toString()),
//                   onTap: () {
//                     Navigator.push(
//                       context,
//                       MaterialPageRoute(
//                         builder: (context) => WriteAndTextPage(
//                           text: document.pdfContent,
//                           isText: false,
//                         ),
//                       ),
//                     );
//                   },
//                 );
//               },
//             );
//           }
//         },
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:new_wall_paper_app/audio-to-text/model/store-pdf-sqlite-db-model.dart';
import 'package:new_wall_paper_app/audio-to-text/page/write-past-text.dart';
import 'package:new_wall_paper_app/widget/sqlite-helper.dart';

class OpenedPdfsPage extends StatefulWidget {
  const OpenedPdfsPage({Key? key}) : super(key: key);

  @override
  _OpenedPdfsPageState createState() => _OpenedPdfsPageState();
}

class _OpenedPdfsPageState extends State<OpenedPdfsPage> {
  late Future<List<Document>> _savedDocuments;

  @override
  void initState() {
    super.initState();
    _savedDocuments = DatabaseHelper().getDocuments();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Saved PDF Contents"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _savedDocuments = DatabaseHelper().getDocuments();
              });
            },
          ),
        ],
      ),
      body: FutureBuilder<List<Document>>(
        future: _savedDocuments,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text("No saved content found"));
          } else {
            final documents = snapshot.data!;
            return ListView.builder(
              itemCount: documents.length,
              itemBuilder: (context, index) {
                final document = documents[index];
                return ListTile(
                  leading: CircleAvatar(
                    radius: MediaQuery.of(context).size.height * 0.03,
                    child: Text(
                      document.contentType ?? "File",
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                  trailing: IconButton(
                    onPressed: () async {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text("Delete Document"),
                          content: Text(
                              "Are you sure you want to delete '${document.name}'?"),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text("Cancel"),
                            ),
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              child: const Text("Delete"),
                            ),
                          ],
                        ),
                      );

                      if (confirm == true) {
                        await DatabaseHelper().deleteDocument(document.id!);
                        setState(() {
                          _savedDocuments = DatabaseHelper().getDocuments();
                        });

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content:
                                  Text("Document '${document.name}' deleted")),
                        );
                      }
                    },
                    icon: const Icon(
                      Icons.delete,
                      color: Colors.red,
                    ),
                  ),
                  title: Text(document.name ?? "No Name"),
                  subtitle: Text(document.description ?? ""),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => WriteAndTextPage(
                          text: document.pdfContent,
                          isText: false,
                        ),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
