// ignore_for_file: sized_box_for_whitespace, use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/svg.dart';
import 'package:new_wall_paper_app/audio-to-text/bloc/home-page-bloc/home-bloc.dart';
import 'package:new_wall_paper_app/audio-to-text/bloc/home-page-bloc/home-event.dart';
import 'package:new_wall_paper_app/audio-to-text/bloc/home-page-bloc/home-state.dart';
import 'package:new_wall_paper_app/audio-to-text/page/docs-reader-screen.dart';
import 'package:new_wall_paper_app/audio-to-text/page/file-picker.dart';
import 'package:new_wall_paper_app/audio-to-text/page/google_drive_reader_screen.dart';
import 'package:new_wall_paper_app/audio-to-text/page/imgReader-screen.dart';
import 'package:new_wall_paper_app/audio-to-text/page/link_reader_screen.dart';
import 'package:new_wall_paper_app/audio-to-text/page/read_email/mail_folder.dart';
import 'package:new_wall_paper_app/audio-to-text/page/write-past-text.dart';
import 'package:new_wall_paper_app/utils/app-color.dart';
import 'package:new_wall_paper_app/widget/common-text.dart';
import 'package:new_wall_paper_app/widget/height-widget.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    context.read<HomePageBloc>().add(LoadItemsEvent());

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: AppColor.homeBgColor,
      body: BlocBuilder<HomePageBloc, HomePageSate>(builder: (context, state) {
        if (state is ItemLoading) {
          return const Center(child: CircularProgressIndicator());
        } else if (state is ItemLoaded) {
          return ListView(
            children: [
              SizedBox(height: MediaQuery.of(context).size.height * .1),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 17),
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
                height: MediaQuery.of(context).size.height * 0.15,
                width: double.infinity,
                decoration: BoxDecoration(
                    color: AppColor.primaryColor,
                    borderRadius: BorderRadius.circular(10)),
                child: Center(
                  child: CommonText(
                    color: Colors.white,
                    size: 0.017,
                    title: "Ads Container",
                  ),
                ),
              ),
              height(size: 0.025),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 17),
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    height(size: 0.01),
                    CommonText(
                      color: Colors.black,
                      size: 0.02,
                      fontWeight: FontWeight.w500,
                      title: "Import & Listen",
                    ),
                    height(size: 0.02),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: state.items.length,
                      itemBuilder: (context, index) {
                        final item = state.items[index];
                        return InkWell(
                          onTap: () {
                            if (item.text == 'Pic') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ImageReaderScreen(
                                          isCamera: false,
                                        )),
                              );
                            } else if (item.text == 'More') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => DocxReaderHome()),
                              );
                            } else if (item.text == 'Files') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        // const PDFToTextScreen()),
                                         FileProcessorScreen()),
                              );
                            } else if (item.text == 'Text') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => WriteAndTextPage(
                                       isText: true,
                                    )),
                              );
                            } else if (item.text == "Scan") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => ImageReaderScreen(
                                          isCamera: true,
                                        )),
                              );
                            } else if (item.text == "Link") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LinkReaderScreen()),
                              );
                            } else if (item.text == "Gdrive") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        DriveFolderScreen()),
                              );
                            } else if (item.text == "Email") {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        EmailFolderScreen()),
                              );
                            }
                          },
                          child: Container(
                            height: MediaQuery.of(context).size.height * 0.1,
                            width: MediaQuery.of(context).size.width * 0.1,
                            decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: AppColor.homeIconBackColor),
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  SvgPicture.asset(
                                    item.imageUrl,
                                    height: MediaQuery.of(context).size.height *
                                        0.025,
                                  ),
                                  height(size: 0.01),
                                  CommonText(
                                    color: Colors.black,
                                    size: 0.016,
                                    fontWeight: FontWeight.normal,
                                    title: item.text,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              height(size: 0.02),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 17),
                padding:
                    const EdgeInsets.symmetric(horizontal: 15, vertical: 9),
                width: double.infinity,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CommonText(
                          color: Colors.black,
                          size: 0.02,
                          fontWeight: FontWeight.w500,
                          title: "Explore Book",
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          size: MediaQuery.of(context).size.height * 0.03,
                        )
                      ],
                    ),
                    height(size: 0.02),
                    Container(
                      height: MediaQuery.of(context).size.height * 0.06,
                      width: double.infinity,
                      child: Center(
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: const AlwaysScrollableScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemCount: state.texts?.length,
                          itemBuilder: (context, index) {
                            return Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 4),
                                decoration: BoxDecoration(
                                    color: AppColor.greyColor.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(6)),
                                child: Center(
                                    child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 10),
                                  child: Text(state.texts?[index] ?? ""),
                                )));
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          );
        } else if (state is ItemError) {
          return Center(child: Text(state.message));
        }
        return const Center(child: Text('No data available'));
      }),
    );
  }
}
