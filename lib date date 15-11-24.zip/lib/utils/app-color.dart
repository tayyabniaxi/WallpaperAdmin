import 'package:flutter/material.dart';

class AppColor {
  static const Color primaryColor = Color(0xff171749);
  static const Color homeBgColor = Color(0xffEEF2FD);
  static const Color homeIconBackColor = Color(0xffECEBF0);
  static const Color homePinkContainerColor = Color(0xffFFF0ED);
  static const Color homeblueContainerColor = Color(0xffECF2FE);
  static const Color greyColor = Colors.grey;
}
