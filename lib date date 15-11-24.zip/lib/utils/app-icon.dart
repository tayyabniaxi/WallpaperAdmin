// ignore_for_file: file_names

class AppImage {
  static const String basePath = "assets/svg/";
  static const String premiumImage = "${basePath}premuim.svg";
  static const String cameraImage = "${basePath}camera.svg";
  static const String importWeb = "${basePath}import_web.svg";
  static const String importDocs = "${basePath}import_docs.svg";
  static const String write = "${basePath}write.svg";
  static const String attach = "${basePath}attach.svg";
  static const String emial = "${basePath}email.svg";
  static const String gdive = "${basePath}gdrive.svg";
  static const String file = "${basePath}file.svg";
  static const String scan = "${basePath}scan.svg";
  static const String text = "${basePath}text.svg";
  static const String pic = "${basePath}pic.svg";
  static const String plus = "${basePath}plus.svg";
  static const String search = "${basePath}search.svg";
  static const String profile = "${basePath}profile.svg";
  static const String home = "${basePath}home.svg";
  static const String history = "${basePath}history.svg";
}
