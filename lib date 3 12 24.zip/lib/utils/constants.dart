class Constants {
  //ip of the laptop that the server is running on
  static String uri = 'http://192.168.43.72:3000';
}

