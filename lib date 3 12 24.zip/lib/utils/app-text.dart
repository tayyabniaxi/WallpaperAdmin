class AppText {
  static const String writePastText = "Write or Paste Text";
  static const String file = "Files";
  static const String gdrive = "GDriver";
  static const String pic = "Kindly";
  static const String email = "Gmail";
  static const String scan = "Scan";
  static const String text = "Text";
  static const String link = "Link";
  static const String more = "More";
  static const String failedToLoadItem = "Failed to load items";
}
